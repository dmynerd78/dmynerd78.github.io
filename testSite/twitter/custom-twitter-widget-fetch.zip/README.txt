A Pen created at CodePen.io. You can find this one at http://codepen.io/nerijusgood/pen/Ggqygo.

 Nobody likes classic twitter widget. This is an example of how can twitter feed, hashtag, search query could be customized and used in any kind of website. As well us Twitter Widget Custom css styling